import tkinter as tk
from tkinter import scrolledtext
import sqlite3
import json

# ✅ Connect to the correct database
conn = sqlite3.connect("final_survival_ai_with_bible.db")
cursor = conn.cursor()

# 🔍 Main search function
def search_all(event=None):
    query = entry.get()
    output.delete(1.0, tk.END)

    # 📖 Bible Search
    try:
        cursor.execute("SELECT book_name, chapter, verse, text FROM bible WHERE text LIKE ?", ('%' + query + '%',))
        bible_results = cursor.fetchall()
        if bible_results:
            output.insert(tk.END, "=== Bible Results ===\n")
            for book, chapter, verse, text in bible_results:
                output.insert(tk.END, f"{book} {chapter}:{verse} - {text}\n\n")
        else:
            output.insert(tk.END, "No Bible results found.\n\n")
    except Exception as e:
        output.insert(tk.END, f"Bible search error: {e}\n")

    # 🛟 Survival Guide Search
    try:
        cursor.execute("SELECT topic, content FROM survival_guides WHERE content LIKE ?", ('%' + query + '%',))
        survival_results = cursor.fetchall()
        if survival_results:
            output.insert(tk.END, "=== Survival Guide Results ===\n")
            for topic, content in survival_results:
                output.insert(tk.END, f"\n🔷 {topic} 🔷\n")
                try:
                    maybe_json = json.loads(content)
                    if isinstance(maybe_json, dict):
                        for method, details in maybe_json.items():
                            output.insert(tk.END, f"🔹 {method}: {details}\n")
                    else:
                        output.insert(tk.END, f"{content}\n")
                except Exception:
                    output.insert(tk.END, f"{content}\n")
        else:
            output.insert(tk.END, "No Survival Guide results found.\n")
    except Exception as e:
        output.insert(tk.END, f"\nSurvival guide search error: {e}\n")

# 🖼️ GUI Layout
window = tk.Tk()
window.title("Survival AI with Bible")

tk.Label(window, text="Enter keyword or phrase:").pack()
entry = tk.Entry(window, width=50)
entry.pack()
entry.bind("<Return>", search_all)